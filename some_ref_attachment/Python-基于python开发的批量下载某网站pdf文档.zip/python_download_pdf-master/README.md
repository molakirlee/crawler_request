# python_download_pdf
基于python开发的批量下载某网站pdf文档

[我的GitHub](https://github.com/lflyou1314)

# [说明]
1.	打开chrome浏览器
输入http://www.bootcss.com/
 
2.	按下键盘F12键
打开Chrome DevTools
 
3.	Console下输入代码并回车
便可以获取网站的目标数据信息

返回的json数据包含了真实pdf的下载路径，则需要解析json数据，拼接为实际的下载地址并下载

4.	Python代码实现

    

    
